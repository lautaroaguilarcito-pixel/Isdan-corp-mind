ISDAN MIND - app instalable (PWA)
1) Doble clic en index.html: funciona directamente (datos guardados en el navegador).
2) Para INSTALAR como app (celular o PC) y usarla offline, sírvela por http(s):
   - PC:  en esta carpeta ejecuta  python3 -m http.server 8080  y abre http://localhost:8080
          -> icono "Instalar" en la barra de Chrome/Edge.
   - Celular: sube la carpeta a Netlify Drop / GitHub Pages / Cloudflare Pages
          -> Chrome: menú > "Instalar app" ; iOS Safari: Compartir > "Agregar a inicio".
